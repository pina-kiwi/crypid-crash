namespace ItsAdventureTime;

public class ItemJsonData
{
    public string Name {get; set;}
    public string Description {get; set;}
    public string InitialDescription {get; set;}
    public bool IsTakeable {get; set;}
    public string Location {get; set;}
}